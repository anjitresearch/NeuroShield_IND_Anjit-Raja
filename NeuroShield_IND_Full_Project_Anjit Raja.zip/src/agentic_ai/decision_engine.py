
def defence_decision(threat, stress):
    if threat == 1 and stress < 2:
        return "Trigger Silent Alert"
    elif stress == 2:
        return "Activate Safety Lock"
    else:
        return "Normal Operation"
