
NeuroShield-IND Project

This project demonstrates an EEG-based Brain–Computer Interface
for Indian Defence cognitive threat anticipation.

Contents:
- dataset/: Synthetic EEG dataset
- src/: Signal processing, ML models, agentic AI, security
- docs/: Architecture & documentation

This package is for academic and research use only.
